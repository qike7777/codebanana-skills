#!/usr/bin/env python3
"""
compress_pdf.py — Compress a PDF file using multiple strategies.

Strategies:
  qpdf_optimize  — lossless optimization via qpdf (fast, ~10-30% reduction)
  gs_screen      — Ghostscript, 72dpi images, smallest file, screen only
  gs_ebook       — Ghostscript, 150dpi images, good balance (DEFAULT)
  gs_printer     — Ghostscript, 300dpi images, print quality
  gs_prepress    — Ghostscript, 300dpi + color profiles, highest quality

Usage:
    python3 compress_pdf.py --input input.pdf --output compressed.pdf --strategy gs_ebook
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


def human_size(num_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if num_bytes < 1024:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} TB"


def compress_qpdf(input_path: str, output_path: str) -> bool:
    if not shutil.which("qpdf"):
        print("⚠️  qpdf 未安装。请运行: apt install qpdf", file=sys.stderr)
        return False
    result = subprocess.run(
        ["qpdf", "--optimize-images", "--recompress-flate",
         "--compression-level=9", input_path, output_path],
        capture_output=True, text=True
    )
    if result.returncode not in (0, 3):  # 3 = warnings only
        print(f"qpdf 错误: {result.stderr}", file=sys.stderr)
        return False
    return True


def compress_ghostscript(input_path: str, output_path: str, quality: str) -> bool:
    if not shutil.which("gs"):
        print("⚠️  Ghostscript 未安装。请运行: apt install ghostscript", file=sys.stderr)
        return False

    gs_settings = {
        "gs_screen":   "/screen",
        "gs_ebook":    "/ebook",
        "gs_printer":  "/printer",
        "gs_prepress": "/prepress",
    }
    setting = gs_settings.get(quality, "/ebook")

    result = subprocess.run([
        "gs", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.4",
        f"-dPDFSETTINGS={setting}",
        "-dNOPAUSE", "-dQUIET", "-dBATCH",
        f"-sOutputFile={output_path}",
        input_path
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"Ghostscript 错误: {result.stderr}", file=sys.stderr)
        return False
    return True


def compress(input_path: str, output_path: str, strategy: str) -> None:
    input_size = os.path.getsize(input_path)
    print(f"📄 输入文件：{input_path} ({human_size(input_size)})")
    print(f"🔧 压缩策略：{strategy}")

    success = False
    if strategy == "qpdf_optimize":
        success = compress_qpdf(input_path, output_path)
    elif strategy in ("gs_screen", "gs_ebook", "gs_printer", "gs_prepress"):
        success = compress_ghostscript(input_path, output_path, strategy)
    else:
        print(f"❌ 未知策略：{strategy}", file=sys.stderr)
        sys.exit(1)

    if not success:
        print("❌ 压缩失败", file=sys.stderr)
        sys.exit(1)

    if not os.path.exists(output_path):
        print("❌ 输出文件未生成", file=sys.stderr)
        sys.exit(1)

    output_size = os.path.getsize(output_path)
    ratio = (1 - output_size / input_size) * 100 if input_size > 0 else 0

    print(f"\n✅ 压缩完成 → {output_path}")
    print(f"   原始大小：{human_size(input_size)}")
    print(f"   压缩后：  {human_size(output_size)}")
    print(f"   压缩率：  {ratio:.1f}%")

    if output_size >= input_size:
        print("⚠️  注意：压缩后文件没有变小（原文件可能已经过压缩）")


def main():
    parser = argparse.ArgumentParser(description="Compress PDF file")
    parser.add_argument("--input",    required=True, help="Input PDF path")
    parser.add_argument("--output",   required=True, help="Output PDF path")
    parser.add_argument("--strategy", default="gs_ebook",
                        choices=["qpdf_optimize", "gs_screen", "gs_ebook",
                                 "gs_printer", "gs_prepress"],
                        help="Compression strategy (default: gs_ebook)")
    args = parser.parse_args()
    compress(args.input, args.output, args.strategy)


if __name__ == "__main__":
    main()
