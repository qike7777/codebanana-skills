#!/usr/bin/env python3
"""
images_to_pdf.py — Merge one or more images into a single PDF.

Supported formats: JPG, PNG, BMP, TIFF, WebP

Usage:
    # Explicit file list
    python3 images_to_pdf.py --input scan1.jpg scan2.png --output merged.pdf

    # Directory + pattern
    python3 images_to_pdf.py --input-dir ./scans/ --pattern "*.jpg" --output merged.pdf

    # Fit modes:
    #   fill     — stretch to fill the full page (default, good for scans)
    #   fit      — keep aspect ratio, add white margins
    #   original — no scaling, use image's natural size as page size
"""

import argparse
import glob
import os
import sys
from pathlib import Path

from PIL import Image
from reportlab.lib.pagesizes import A4, A3, letter
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas


PAGE_SIZES = {
    "A4":     A4,
    "A3":     A3,
    "letter": letter,
}

SUPPORTED_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}


def collect_images(input_files=None, input_dir=None, pattern="*.jpg") -> list[str]:
    if input_files:
        return [f for f in input_files if Path(f).suffix.lower() in SUPPORTED_EXTS]
    if input_dir:
        files = sorted(glob.glob(os.path.join(input_dir, pattern)))
        return [f for f in files if Path(f).suffix.lower() in SUPPORTED_EXTS]
    return []


def images_to_pdf(image_paths: list[str], output_path: str,
                  page_size_name: str = "A4", fit_mode: str = "fill") -> None:
    if not image_paths:
        print("❌ 没有找到图片文件", file=sys.stderr)
        sys.exit(1)

    page_size = PAGE_SIZES.get(page_size_name.upper(), A4)
    page_w, page_h = page_size

    c = canvas.Canvas(output_path)

    for i, img_path in enumerate(image_paths):
        print(f"  处理 ({i+1}/{len(image_paths)}): {os.path.basename(img_path)}")

        try:
            img = Image.open(img_path)
            # Convert to RGB if needed (e.g., RGBA PNG)
            if img.mode in ("RGBA", "P", "LA"):
                background = Image.new("RGB", img.size, (255, 255, 255))
                if img.mode == "P":
                    img = img.convert("RGBA")
                background.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
                img = background
            elif img.mode != "RGB":
                img = img.convert("RGB")

            img_w_px, img_h_px = img.size

            if fit_mode == "original":
                # Use image's natural size as page size (72 dpi assumption)
                pw = img_w_px
                ph = img_h_px
                c.setPageSize((pw, ph))
                c.drawInlineImage(img, 0, 0, width=pw, height=ph)

            elif fit_mode == "fit":
                # Keep aspect ratio, center on page with white margins
                c.setPageSize(page_size)
                ratio = min(page_w / img_w_px, page_h / img_h_px)
                draw_w = img_w_px * ratio
                draw_h = img_h_px * ratio
                x = (page_w - draw_w) / 2
                y = (page_h - draw_h) / 2
                c.drawInlineImage(img, x, y, width=draw_w, height=draw_h)

            else:  # fill (default)
                c.setPageSize(page_size)
                c.drawInlineImage(img, 0, 0, width=page_w, height=page_h)

        except Exception as e:
            print(f"  ⚠️  跳过 {img_path}: {e}", file=sys.stderr)
            continue

        c.showPage()

    c.save()
    print(f"\n✅ 合并完成 → {output_path}")
    print(f"   共 {len(image_paths)} 张图片 → {len(image_paths)} 页 PDF")


def main():
    parser = argparse.ArgumentParser(description="Merge images into a PDF")
    parser.add_argument("--input",      nargs="+", help="Image file paths")
    parser.add_argument("--input-dir",  help="Directory containing images")
    parser.add_argument("--pattern",    default="*.jpg", help="Glob pattern for input-dir mode")
    parser.add_argument("--output",     required=True, help="Output PDF path")
    parser.add_argument("--page-size",  default="A4", choices=["A4", "A3", "letter"],
                        help="Page size (default: A4)")
    parser.add_argument("--fit-mode",   default="fill", choices=["fill", "fit", "original"],
                        help="How to fit images on page (default: fill)")
    args = parser.parse_args()

    image_paths = collect_images(
        input_files=args.input,
        input_dir=args.input_dir,
        pattern=args.pattern
    )

    if not image_paths:
        print("❌ 未找到任何图片文件，请检查路径或 pattern", file=sys.stderr)
        sys.exit(1)

    print(f"📷 找到 {len(image_paths)} 张图片")
    for p in image_paths:
        print(f"   • {os.path.basename(p)}")

    images_to_pdf(image_paths, args.output, args.page_size, args.fit_mode)


if __name__ == "__main__":
    main()
