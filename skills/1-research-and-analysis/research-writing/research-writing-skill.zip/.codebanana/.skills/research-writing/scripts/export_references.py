#!/usr/bin/env python3
"""
export_references.py — Export citations from a research document to xlsx.
Usage: python export_references.py <slug>
Output: research-output/final/<slug>-references.xlsx
"""
import re, sys
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

def parse_references(text: str) -> list[str]:
    """Extract lines from the References section."""
    match = re.search(r'#{1,2}\s+References?\n(.*?)(?=\n#{1,2} |\Z)', text, re.DOTALL | re.IGNORECASE)
    if not match:
        return []
    lines = [l.strip() for l in match.group(1).strip().split('\n') if l.strip()]
    # Strip leading numbering like "1.", "[1]", "- "
    cleaned = []
    for l in lines:
        l = re.sub(r'^[\[\(]?\d+[\]\)\.]\s*', '', l)
        l = re.sub(r'^[-*]\s+', '', l)
        if l:
            cleaned.append(l)
    return cleaned

def guess_parts(ref: str) -> dict:
    """Best-effort parse of author / year / title from a citation string."""
    parts = {"authors": "", "year": "", "title": ref, "source": "", "doi": ""}
    # Year
    year_m = re.search(r'\b(19|20)\d{2}\b', ref)
    if year_m:
        parts["year"] = year_m.group(0)
    # DOI / URL
    doi_m = re.search(r'(https?://\S+|doi\.org/\S+|10\.\d{4}/\S+)', ref)
    if doi_m:
        parts["doi"] = doi_m.group(1)
    # Authors — everything before the year (rough)
    if year_m:
        parts["authors"] = ref[:year_m.start()].rstrip('. (')
    return parts

def build_xlsx(refs: list[str], out_path: Path, citation_style: str = "APA"):
    wb = Workbook()
    ws = wb.active
    ws.title = "References"

    NAVY  = "1A2E4A"
    AMBER = "E8A020"
    AMBER_LIGHT = "FEF6E4"
    WHITE = "FFFFFF"
    LIGHT_GRAY = "F8F9FB"

    thin = Side(style='thin', color="E5E7EB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    headers = ["#", "Authors", "Year", "Title / Full Citation", "Journal / Source", "DOI / URL", "Style", "Notes"]
    col_widths = [5, 28, 7, 60, 28, 38, 8, 20]

    # Header row
    for col, (h, w) in enumerate(zip(headers, col_widths), 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = Font(bold=True, color=WHITE, name="Calibri", size=11)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
        ws.column_dimensions[cell.column_letter].width = w
    ws.row_dimensions[1].height = 28

    # Data rows
    for i, ref in enumerate(refs, 1):
        p = guess_parts(ref)
        row_fill = PatternFill("solid", fgColor=LIGHT_GRAY if i % 2 == 0 else WHITE)
        values = [i, p["authors"], p["year"], p["title"], p["source"], p["doi"], citation_style, ""]
        for col, val in enumerate(values, 1):
            cell = ws.cell(row=i+1, column=col, value=val)
            cell.font = Font(name="Calibri", size=10)
            cell.fill = row_fill
            cell.alignment = Alignment(vertical="top", wrap_text=(col == 4))
            cell.border = border
        ws.row_dimensions[i+1].height = 40 if len(ref) > 100 else 22

    # Freeze header
    ws.freeze_panes = "A2"

    # Summary row at bottom
    summary_row = len(refs) + 2
    cell = ws.cell(row=summary_row, column=1, value=f"Total: {len(refs)} references")
    cell.font = Font(bold=True, color=NAVY, name="Calibri", size=10)
    cell.fill = PatternFill("solid", fgColor=AMBER_LIGHT)
    ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=8)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    return len(refs)

def main():
    slug = sys.argv[1] if len(sys.argv) > 1 else "document"
    md_path = Path(f"research-output/final/{slug}.md")

    if not md_path.exists():
        print(f"ERROR: {md_path} not found.")
        print("Usage: python export_references.py <slug>")
        print("Example: python export_references.py remote-work-productivity")
        sys.exit(1)

    text = md_path.read_text(encoding="utf-8")

    # Get citation style from frontmatter
    style_m = re.search(r'^citation_style:\s*["\']?(\w+)', text, re.MULTILINE)
    citation_style = style_m.group(1) if style_m else "APA"

    refs = parse_references(text)
    if not refs:
        print("No References section found in the document.")
        sys.exit(0)

    out_path = Path(f"research-output/final/{slug}-references.xlsx")
    count = build_xlsx(refs, out_path, citation_style)

    print(f"✅ Exported {count} references → {out_path}")

if __name__ == "__main__":
    main()
