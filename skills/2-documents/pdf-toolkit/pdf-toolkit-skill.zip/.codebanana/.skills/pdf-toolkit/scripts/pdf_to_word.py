#!/usr/bin/env python3
"""
pdf_to_word.py — Convert PDF to Word (.docx), preserving paragraph structure.

Strategy:
  - pdfplumber extracts text with layout awareness
  - Headings detected by font size heuristics
  - Tables extracted and inserted as Word tables
  - Images noted as placeholders (cannot be reliably extracted from all PDFs)

Usage:
    python3 pdf_to_word.py --input document.pdf --output document.docx
    python3 pdf_to_word.py --input document.pdf --output document.docx --extract-tables
"""

import argparse
import re
import sys
from pathlib import Path

import pdfplumber
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH


# Heuristic: lines with very large font size are likely headings
HEADING_FONT_THRESHOLD = 14   # pts above which we treat as heading
SUBHEADING_FONT_THRESHOLD = 12


def detect_heading_level(line_text: str, char_sizes: list[float]) -> int:
    """Return heading level (1/2/0) based on font sizes in the line."""
    if not char_sizes:
        return 0
    avg_size = sum(char_sizes) / len(char_sizes)
    if avg_size >= HEADING_FONT_THRESHOLD:
        return 1
    if avg_size >= SUBHEADING_FONT_THRESHOLD:
        return 2
    return 0


def extract_char_sizes(page, line_text: str) -> list[float]:
    """Extract font sizes for characters in a line (best effort)."""
    try:
        chars = page.chars
        sizes = [
            c["size"] for c in chars
            if c.get("text", "").strip() and c["text"] in line_text
        ]
        return sizes[:len(line_text)]
    except Exception:
        return []


def pdf_to_word(input_path: str, output_path: str, extract_tables: bool = True) -> None:
    doc = Document()

    # Set default font
    style = doc.styles["Normal"]
    style.font.name = "Arial"
    style.font.size = Pt(11)

    total_pages = 0
    total_paragraphs = 0
    total_tables = 0

    with pdfplumber.open(input_path) as pdf:
        total_pages = len(pdf.pages)
        print(f"📄 输入：{input_path}（{total_pages} 页）")

        for page_num, page in enumerate(pdf.pages, start=1):
            print(f"   处理第 {page_num}/{total_pages} 页...", end="\r", flush=True)

            # ── Extract tables first ──────────────────────────────────────────
            table_bboxes = []
            if extract_tables:
                tables = page.extract_tables()
                for table_data in tables:
                    if not table_data:
                        continue
                    # Find table bounding box to exclude from text extraction
                    try:
                        found = page.find_tables()
                        for t in found:
                            table_bboxes.append(t.bbox)
                    except Exception:
                        pass

                    # Add table to Word doc
                    rows = [r for r in table_data if any(c for c in r)]
                    if not rows:
                        continue
                    num_cols = max(len(r) for r in rows)
                    word_table = doc.add_table(rows=len(rows), cols=num_cols)
                    word_table.style = "Table Grid"

                    for r_idx, row in enumerate(rows):
                        for c_idx, cell_val in enumerate(row):
                            if c_idx < num_cols:
                                cell = word_table.cell(r_idx, c_idx)
                                cell.text = str(cell_val) if cell_val else ""

                    doc.add_paragraph()
                    total_tables += 1

            # ── Extract text ──────────────────────────────────────────────────
            text = page.extract_text()
            if not text:
                continue

            lines = text.split("\n")
            for line in lines:
                line = line.strip()
                if not line:
                    continue

                # Detect heading level
                char_sizes = extract_char_sizes(page, line)
                heading_level = detect_heading_level(line, char_sizes)

                if heading_level == 1:
                    doc.add_heading(line, level=1)
                elif heading_level == 2:
                    doc.add_heading(line, level=2)
                else:
                    doc.add_paragraph(line)
                total_paragraphs += 1

            # Page break between pages (optional, keeps page context)
            if page_num < total_pages:
                doc.add_page_break()

    doc.save(output_path)
    print(f"\n✅ 转换完成 → {output_path}")
    print(f"   页数：{total_pages} 页")
    print(f"   段落：{total_paragraphs} 段")
    if extract_tables:
        print(f"   表格：{total_tables} 张")
    print()
    print("⚠️  注意：复杂排版（多栏、浮动图片、特殊字体）转换后格式会简化，")
    print("   这是 PDF 格式特性限制，建议在 Word 中手动调整。")


def main():
    parser = argparse.ArgumentParser(description="Convert PDF to Word (.docx)")
    parser.add_argument("--input",           required=True, help="Input PDF path")
    parser.add_argument("--output",          required=True, help="Output .docx path")
    parser.add_argument("--extract-tables",  action="store_true", default=True,
                        help="Extract tables into Word tables (default: True)")
    parser.add_argument("--no-tables",       action="store_true",
                        help="Skip table extraction (text only)")
    args = parser.parse_args()

    extract_tables = args.extract_tables and not args.no_tables
    pdf_to_word(args.input, args.output, extract_tables=extract_tables)


if __name__ == "__main__":
    main()
