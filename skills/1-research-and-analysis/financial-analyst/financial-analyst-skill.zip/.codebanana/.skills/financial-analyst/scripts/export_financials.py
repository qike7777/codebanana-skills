#!/usr/bin/env python3
"""
export_financials.py — Export financial model data to a structured xlsx workbook.

Usage:
  python export_financials.py              # interactive: reads from model-data.json
  python export_financials.py --demo       # creates a demo workbook with sample data

Output: financial-output/financial-model-<company>.xlsx
"""
import sys, json, re
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
from openpyxl.utils import get_column_letter

# ── Color palette ────────────────────────────────────────────────────────────
NAVY       = "1A2E4A"
AMBER      = "E8A020"
AMBER_LIGHT= "FEF6E4"
GREEN      = "166534"
GREEN_LIGHT= "DCFCE7"
RED        = "991B1B"
RED_LIGHT  = "FEE2E2"
BLUE       = "1D4ED8"
BLUE_LIGHT = "DBEAFE"
GRAY_DARK  = "374151"
GRAY_MID   = "9CA3AF"
GRAY_LIGHT = "F3F4F6"
WHITE      = "FFFFFF"

def thin_border(color="E5E7EB"):
    s = Side(style='thin', color=color)
    return Border(left=s, right=s, top=s, bottom=s)

def header_cell(ws, row, col, value, bg=NAVY, fg=WHITE, bold=True, size=11, align="center"):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, color=fg, name="Calibri", size=size)
    c.fill = PatternFill("solid", fgColor=bg)
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    c.border = thin_border()
    return c

def data_cell(ws, row, col, value, fmt=None, bold=False, bg=WHITE, fg=GRAY_DARK, align="right"):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, color=fg, name="Calibri", size=10)
    c.fill = PatternFill("solid", fgColor=bg)
    c.alignment = Alignment(horizontal=align, vertical="center")
    c.border = thin_border()
    if fmt:
        c.number_format = fmt
    return c

# ── Sheet 1: Income Statement ────────────────────────────────────────────────
def build_income_statement(wb, data: dict):
    ws = wb.create_sheet("Income Statement")
    company = data.get("company", "Company")
    periods = data.get("periods", ["Q1", "Q2", "Q3", "Q4", "FY"])

    # Title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(periods)+1)
    t = ws.cell(row=1, column=1, value=f"Income Statement — {company}")
    t.font = Font(bold=True, color=WHITE, name="Calibri", size=14)
    t.fill = PatternFill("solid", fgColor=NAVY)
    t.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # Period headers
    header_cell(ws, 2, 1, "Category", align="left")
    for i, p in enumerate(periods, 2):
        header_cell(ws, 2, i, p)
    ws.row_dimensions[2].height = 24

    # Section data
    sections = data.get("income_statement", {})
    row = 3
    for section_name, items in sections.items():
        # Section header
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(periods)+1)
        sc = ws.cell(row=row, column=1, value=section_name.upper())
        sc.font = Font(bold=True, color=WHITE, name="Calibri", size=10)
        sc.fill = PatternFill("solid", fgColor=GRAY_DARK)
        sc.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.row_dimensions[row].height = 20
        row += 1
        for item_name, values in items.items():
            is_total = "total" in item_name.lower() or "margin" in item_name.lower() or "ebitda" in item_name.lower()
            bg = AMBER_LIGHT if is_total else (GRAY_LIGHT if row % 2 == 0 else WHITE)
            bold = is_total
            data_cell(ws, row, 1, item_name, align="left", bold=bold, bg=bg)
            for i, v in enumerate(values[:len(periods)], 2):
                fmt = '0.0"%"' if "%" in str(item_name) or "margin" in item_name.lower() else '"$"#,##0'
                data_cell(ws, row, i, v, fmt=fmt, bold=bold, bg=bg)
            ws.row_dimensions[row].height = 18
            row += 1
        row += 1  # blank between sections

    # Column widths
    ws.column_dimensions["A"].width = 32
    for i in range(2, len(periods)+2):
        ws.column_dimensions[get_column_letter(i)].width = 13
    ws.freeze_panes = "B3"

# ── Sheet 2: Cash Flow & Runway ──────────────────────────────────────────────
def build_cash_flow(wb, data: dict):
    ws = wb.create_sheet("Cash Flow & Runway")
    company = data.get("company", "Company")
    months = data.get("months", [f"M{i}" for i in range(1, 13)])

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(months)+1)
    t = ws.cell(row=1, column=1, value=f"Cash Flow & Runway — {company}")
    t.font = Font(bold=True, color=WHITE, name="Calibri", size=14)
    t.fill = PatternFill("solid", fgColor=NAVY)
    t.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    header_cell(ws, 2, 1, "Line Item", align="left")
    for i, m in enumerate(months, 2):
        header_cell(ws, 2, i, m)
    ws.row_dimensions[2].height = 24

    cf_data = data.get("cash_flow", {})
    row = 3
    for line, values in cf_data.items():
        is_key = any(k in line.lower() for k in ["closing", "runway", "net cash"])
        bg = GREEN_LIGHT if "runway" in line.lower() else (RED_LIGHT if "burn" in line.lower() else (AMBER_LIGHT if is_key else (GRAY_LIGHT if row % 2 == 0 else WHITE)))
        fg = GREEN if "runway" in line.lower() else (RED if "burn" in line.lower() else GRAY_DARK)
        data_cell(ws, row, 1, line, align="left", bold=is_key, bg=bg, fg=fg)
        for i, v in enumerate(values[:len(months)], 2):
            fmt = '0.0' if "runway" in line.lower() else '"$"#,##0'
            data_cell(ws, row, i, v, fmt=fmt, bold=is_key, bg=bg, fg=fg)
        ws.row_dimensions[row].height = 18
        row += 1

    ws.column_dimensions["A"].width = 28
    for i in range(2, len(months)+2):
        ws.column_dimensions[get_column_letter(i)].width = 10
    ws.freeze_panes = "B3"

# ── Sheet 3: Unit Economics ──────────────────────────────────────────────────
def build_unit_economics(wb, data: dict):
    ws = wb.create_sheet("Unit Economics")
    ue = data.get("unit_economics", {})
    company = data.get("company", "Company")

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
    t = ws.cell(row=1, column=1, value=f"Unit Economics — {company}")
    t.font = Font(bold=True, color=WHITE, name="Calibri", size=14)
    t.fill = PatternFill("solid", fgColor=NAVY)
    t.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    for col, h in enumerate(["Metric", "Value", "Benchmark", "Status"], 1):
        header_cell(ws, 2, col, h, align="left" if col == 1 else "center")
    ws.row_dimensions[2].height = 24

    benchmarks = {
        "ltv_cac": ("> 3x", ">= 3"),
        "gross_margin": ("> 70%", ">= 0.7"),
        "cac_payback_months": ("< 12 mo", "<= 12"),
        "nrr": ("> 100%", ">= 1.0"),
        "monthly_churn": ("< 2%", "<= 0.02"),
    }

    row = 3
    for metric, value in ue.items():
        bg = GRAY_LIGHT if row % 2 == 0 else WHITE
        bmark_text, _ = benchmarks.get(metric, ("—", None))

        # Status indicator
        status = "—"
        if metric in benchmarks:
            try:
                threshold = float(benchmarks[metric][1].replace(">=","").replace("<=","").replace(">","").replace("<","").strip())
                op = ">=" if ">=" in benchmarks[metric][1] else "<="
                v_num = float(str(value).replace("$","").replace("%","").replace("x","").replace(",",""))
                if op == ">=":
                    status = "✅ Good" if v_num >= threshold else "⚠️ Below"
                else:
                    status = "✅ Good" if v_num <= threshold else "⚠️ Above"
            except:
                status = "—"

        status_bg = GREEN_LIGHT if "✅" in status else (RED_LIGHT if "⚠️" in status else bg)

        data_cell(ws, row, 1, metric.replace("_", " ").title(), align="left", bg=bg)
        data_cell(ws, row, 2, value, align="center", bold=True, bg=bg)
        data_cell(ws, row, 3, bmark_text, align="center", bg=bg, fg=GRAY_MID)
        data_cell(ws, row, 4, status, align="center", bg=status_bg)
        ws.row_dimensions[row].height = 22
        row += 1

    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 16
    ws.column_dimensions["D"].width = 14

# ── Sheet 4: Scenarios ────────────────────────────────────────────────────────
def build_scenarios(wb, data: dict):
    ws = wb.create_sheet("Scenario Analysis")
    scenarios = data.get("scenarios", {})
    company = data.get("company", "Company")

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=5)
    t = ws.cell(row=1, column=1, value=f"Scenario Analysis — {company}")
    t.font = Font(bold=True, color=WHITE, name="Calibri", size=14)
    t.fill = PatternFill("solid", fgColor=NAVY)
    t.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    header_cell(ws, 2, 1, "Metric", align="left")
    scenario_colors = {"Bear": RED, "Base": NAVY, "Bull": GREEN}
    for i, name in enumerate(["Bear", "Base", "Bull"], 2):
        header_cell(ws, 2, i, f"🐻 {name}" if name=="Bear" else (f"📊 {name}" if name=="Base" else f"🚀 {name}"),
                    bg=scenario_colors.get(name, NAVY))
    header_cell(ws, 2, 5, "Notes", align="left")
    ws.row_dimensions[2].height = 24

    metrics = set()
    for sc in scenarios.values():
        metrics.update(sc.keys())

    for row, metric in enumerate(sorted(metrics), 3):
        bg = GRAY_LIGHT if row % 2 == 0 else WHITE
        data_cell(ws, row, 1, metric.replace("_", " ").title(), align="left", bg=bg)
        for col, sc_name in enumerate(["Bear", "Base", "Bull"], 2):
            v = scenarios.get(sc_name, {}).get(metric, "—")
            light = {"Bear": RED_LIGHT, "Base": BLUE_LIGHT, "Bull": GREEN_LIGHT}
            data_cell(ws, row, col, v, align="center", bg=light.get(sc_name, bg))
        data_cell(ws, row, 5, "", align="left", bg=bg)
        ws.row_dimensions[row].height = 20

    for col, w in zip("ABCDE", [26, 16, 16, 16, 28]):
        ws.column_dimensions[col].width = w

# ── Main ──────────────────────────────────────────────────────────────────────
DEMO_DATA = {
    "company": "Acme SaaS",
    "periods": ["Q1", "Q2", "Q3", "Q4", "FY"],
    "months": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    "income_statement": {
        "Revenue": {
            "MRR (end of period)": [42000, 50400, 60480, 72576, 72576],
            "ARR": [504000, 604800, 725760, 870912, 870912],
            "Total Revenue": [42000, 50400, 60480, 72576, 225456],
        },
        "Cost of Revenue": {
            "Infrastructure": [4200, 5040, 6048, 7258, 22546],
            "Customer Support": [2100, 2520, 3024, 3629, 11273],
            "Total COGS": [6300, 7560, 9072, 10887, 33819],
            "Gross Margin %": [0.85, 0.85, 0.85, 0.85, 0.85],
        },
        "Operating Expenses": {
            "Engineering": [18000, 18000, 24000, 24000, 84000],
            "Sales & Marketing": [8400, 10080, 12096, 14515, 45091],
            "G&A": [5000, 5000, 5000, 5000, 20000],
            "Total OpEx": [31400, 33080, 41096, 43515, 149091],
            "EBITDA": [-19700, -9740, 10312, 18174, -954],
        },
    },
    "cash_flow": {
        "Opening Cash": [500000, 480300, 470560, 480872, None],
        "Revenue Inflow": [42000, 50400, 60480, 72576, None],
        "Total Costs": [-61700, [-60140], -50168, -54402, None],
        "Net Cash Flow": [-19700, -9740, 10312, 18174, None],
        "Closing Cash": [480300, 470560, 480872, 499046, None],
        "Monthly Burn Rate": [19700, 9740, 0, 0, None],
        "Runway (months)": [24.4, 48.3, 99, 99, None],
    },
    "unit_economics": {
        "ARPU (monthly)": "$420",
        "Gross Margin": "85%",
        "Monthly Churn": "1.8%",
        "CAC": "$1,260",
        "LTV": "$23,333",
        "ltv_cac": "18.5x",
        "cac_payback_months": "3.6 mo",
        "nrr": "108%",
    },
    "scenarios": {
        "Bear":  {"Revenue Growth MoM": "12%", "Monthly Burn": "$25K", "Runway": "19 mo", "ARR EOY": "$610K", "Breakeven": "Q3 2027"},
        "Base":  {"Revenue Growth MoM": "20%", "Monthly Burn": "$15K", "Runway": "33 mo", "ARR EOY": "$871K", "Breakeven": "Q4 2026"},
        "Bull":  {"Revenue Growth MoM": "30%", "Monthly Burn": "$8K",  "Runway": "62 mo", "ARR EOY": "$1.3M", "Breakeven": "Q2 2026"},
    },
}

def main():
    demo = "--demo" in sys.argv
    data_path = Path("financial-output/model-data.json")

    if demo:
        data = DEMO_DATA
    elif data_path.exists():
        data = json.loads(data_path.read_text())
    else:
        print("No model-data.json found. Run with --demo to create a sample workbook.")
        print("Or create financial-output/model-data.json with your financial data.")
        sys.exit(1)

    company = data.get("company", "company").lower().replace(" ", "-")
    out_dir = Path("financial-output")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"financial-model-{company}.xlsx"

    wb = Workbook()
    wb.remove(wb.active)  # remove default sheet

    build_income_statement(wb, data)
    build_cash_flow(wb, data)
    build_unit_economics(wb, data)
    build_scenarios(wb, data)

    wb.save(out_path)
    print(f"✅ Financial model exported → {out_path}")
    print(f"   Sheets: {', '.join(s.title for s in wb.worksheets)}")

if __name__ == "__main__":
    main()
