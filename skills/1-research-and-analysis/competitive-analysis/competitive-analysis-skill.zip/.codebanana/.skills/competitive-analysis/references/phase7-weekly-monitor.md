## Phase 7 — Weekly Competitive Monitor (Cron)

**Setup:** Offered at end of BOOTSTRAP Step 7. Created with `schedule_task` (weekly, Monday 09:00).

### What the weekly task does

Each Monday the agent:

1. Reads `competitive-analysis-output/config.json` to get the competitor list and product context
2. Searches each of the **top 3 competitors** (by threat level in the original report):

| Signal | Query |
|--------|-------|
| Pricing changes | `"{name}" pricing changes OR new plan OR price update site:{domain}` |
| New features / announcements | `"{name}" new feature OR launch OR update {this_month}` |
| Funding / M&A news | `"{name}" funding OR acquired OR raises series {year}` |
| Hiring signals | `"{name}" site:linkedin.com/jobs` (growth areas) |

3. Appends a `## Weekly Update — YYYY-MM-DD` section to the report:

```markdown
## Weekly Update — 2026-03-24

### Competitor Diff
| Competitor | Changed | Signal |
|------------|---------|--------|
| Acme | ✅ New pricing tier ($49/mo "Starter") | Pricing page |
| RivalCo | ⚠️ Raised Series B ($12M) | TechCrunch |
| ThirdTool | — No significant changes | — |

### New Entrants
- None spotted this week.

### Strategic Implication
RivalCo's Series B means they will likely ramp up sales hiring. Expect more aggressive outbound in Q2.
```

### Rules
- Keep each update ≤ 300 words
- Only write to the `## Weekly Update` section; never overwrite earlier content
- If a competitor has no news, write "— No significant changes" — never fabricate activity
- Report is cumulative: all weekly updates stack chronologically at the bottom of the report file
