#!/usr/bin/env python3
"""
processor.py — AI batch processing of a column in an Excel/CSV file.

The agent calls this script to apply a transformation to every row in a column.
The transformation is done by the agent itself via a generated Python function,
passed as --transform-code (a .py snippet that defines transform(value: str) -> str).

Usage:
    python3 processor.py \
        --input data.xlsx \
        --column "产品描述" \
        --transform-code translate_en.py \
        --output data_processed.xlsx \
        [--overwrite]   # overwrite original column instead of creating new one
"""

import argparse
import ast
import csv
import importlib.util
import sys
import types
from pathlib import Path

import openpyxl
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter


HEADER_BG   = "1F4E79"
HEADER_FONT = "FFFFFF"
CHUNK_SIZE  = 50   # report progress every N rows


def load_workbook_or_csv(input_path: str):
    p = Path(input_path)
    if p.suffix.lower() == ".csv":
        wb = openpyxl.Workbook()
        ws = wb.active
        with open(input_path, encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            for row in reader:
                ws.append(row)
        return wb
    return openpyxl.load_workbook(input_path)


def get_header_map(ws):
    return {
        str(ws.cell(row=1, column=i).value).strip(): i
        for i in range(1, ws.max_column + 1)
        if ws.cell(row=1, column=i).value is not None
    }


def load_transform_fn(code_path: str):
    """
    Load transform(value) -> str from a .py file.
    The file must define a function named `transform`.
    """
    spec = importlib.util.spec_from_file_location("transform_module", code_path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "transform"):
        raise ValueError(f"transform.py must define a function named `transform(value)`")
    return mod.transform


def process_column(ws, col_name: str, transform_fn, overwrite: bool = False) -> dict:
    """
    Apply transform_fn to every non-header cell in col_name.
    Returns stats dict.
    """
    header_map = get_header_map(ws)
    if col_name not in header_map:
        raise ValueError(f"列「{col_name}」未找到。可用列：{list(header_map.keys())}")

    src_col_idx = header_map[col_name]
    total_rows  = ws.max_row - 1  # excluding header

    if overwrite:
        dst_col_idx = src_col_idx
        print(f"📝 覆盖列「{col_name}」（{total_rows} 行）...")
    else:
        dst_col_name = col_name + "_AI处理"
        dst_col_idx  = ws.max_column + 1
        # Write new header
        header_cell = ws.cell(row=1, column=dst_col_idx, value=dst_col_name)
        header_cell.fill = PatternFill("solid", fgColor=HEADER_BG)
        header_cell.font = Font(bold=True, color=HEADER_FONT)
        print(f"📝 新增列「{dst_col_name}」（{total_rows} 行）...")

    success = 0
    errors  = 0
    error_rows = []

    for row_idx in range(2, ws.max_row + 1):
        src_value = ws.cell(row=row_idx, column=src_col_idx).value
        src_str   = str(src_value) if src_value is not None else ""

        try:
            result = transform_fn(src_str)
        except Exception as e:
            result = f"[ERROR: {e}]"
            errors += 1
            error_rows.append(row_idx)
        else:
            success += 1

        ws.cell(row=row_idx, column=dst_col_idx, value=result)

        # Progress report
        processed = row_idx - 1
        if processed % CHUNK_SIZE == 0:
            pct = int(processed / total_rows * 100)
            print(f"   进度：{processed}/{total_rows} 行 ({pct}%)", flush=True)

    print(f"   进度：{total_rows}/{total_rows} 行 (100%)")
    return {
        "total":      total_rows,
        "success":    success,
        "errors":     errors,
        "error_rows": error_rows,
        "dst_col":    col_name if overwrite else col_name + "_AI处理"
    }


def main():
    parser = argparse.ArgumentParser(description="AI batch process a column in Excel/CSV")
    parser.add_argument("--input",          required=True,  help="Input .xlsx or .csv")
    parser.add_argument("--column",         required=True,  help="Column name to process")
    parser.add_argument("--transform-code", required=True,  help="Path to .py file with transform(value) function")
    parser.add_argument("--output",         required=True,  help="Output .xlsx path")
    parser.add_argument("--overwrite",      action="store_true", help="Overwrite source column")
    args = parser.parse_args()

    wb = load_workbook_or_csv(args.input)
    ws = wb.active

    transform_fn = load_transform_fn(args.transform_code)

    stats = process_column(ws, args.column, transform_fn, overwrite=args.overwrite)

    wb.save(args.output)

    print(f"\n✅ 文件已生成：{args.output}")
    print(f"📋 处理结果：")
    print(f"   • 总行数：{stats['total']}")
    print(f"   • 成功：{stats['success']}")
    if stats['errors'] > 0:
        print(f"   • 失败：{stats['errors']} 行（第 {stats['error_rows']} 行）")
    print(f"   • 输出列：「{stats['dst_col']}」")


if __name__ == "__main__":
    main()
