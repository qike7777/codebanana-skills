#!/usr/bin/env python3
"""
editor.py — Edit an existing Excel or CSV file based on instructions.

The agent describes the operation in --instruction as a structured JSON action list.
Supported actions:
  - add_column      : add a new column with formula or default value
  - delete_column   : remove a column by name
  - rename_column   : rename a column
  - format_column   : apply number format to a column
  - sort            : sort by column(s)
  - deduplicate     : remove duplicate rows based on column(s)
  - fill_formula    : fill a formula down an existing column
  - pivot_summary   : create a summary sheet grouped by a column

Usage:
    python3 editor.py --input data.xlsx --actions actions.json --output data_edited.xlsx
"""

import argparse
import json
import sys
from pathlib import Path

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter, column_index_from_string
import csv


HEADER_BG   = "1F4E79"
HEADER_FONT = "FFFFFF"
ROW_ALT_BG  = "EBF2FA"


def load_workbook_or_csv(input_path: str):
    """Load .xlsx or .csv into openpyxl Workbook."""
    p = Path(input_path)
    if p.suffix.lower() == ".csv":
        wb = openpyxl.Workbook()
        ws = wb.active
        with open(input_path, encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            for row in reader:
                ws.append(row)
        return wb
    else:
        return openpyxl.load_workbook(input_path)


def get_header_map(ws):
    """Return {col_name: col_index} from row 1."""
    return {
        str(ws.cell(row=1, column=i).value).strip(): i
        for i in range(1, ws.max_column + 1)
        if ws.cell(row=1, column=i).value is not None
    }


def apply_header_style(ws):
    fill = PatternFill("solid", fgColor=HEADER_BG)
    font = Font(bold=True, color=HEADER_FONT, size=11)
    align = Alignment(horizontal="center", vertical="center")
    for cell in ws[1]:
        cell.fill = fill
        cell.font = font
        cell.alignment = align


def apply_actions(wb, actions: list) -> list:
    """Apply a list of action dicts to the workbook. Returns log of operations."""
    ws = wb.active
    log = []

    for action in actions:
        op = action.get("op")

        # ── add_column ──────────────────────────────────────────────────────────
        if op == "add_column":
            name    = action["name"]
            formula = action.get("formula", "")   # e.g. "=(B{row}-C{row})/B{row}"
            default = action.get("default", "")
            fmt     = action.get("format", "")

            new_col = ws.max_column + 1
            ws.cell(row=1, column=new_col, value=name)

            for row in range(2, ws.max_row + 1):
                if formula:
                    val = formula.replace("{row}", str(row))
                else:
                    val = default
                cell = ws.cell(row=row, column=new_col, value=val)
                if fmt:
                    cell.number_format = fmt

            log.append(f"新增列「{name}」（第 {new_col} 列）")

        # ── delete_column ───────────────────────────────────────────────────────
        elif op == "delete_column":
            header_map = get_header_map(ws)
            col_name = action["name"]
            if col_name in header_map:
                ws.delete_cols(header_map[col_name])
                log.append(f"删除列「{col_name}」")
            else:
                log.append(f"⚠️  列「{col_name}」未找到，跳过")

        # ── rename_column ───────────────────────────────────────────────────────
        elif op == "rename_column":
            header_map = get_header_map(ws)
            old_name = action["old"]
            new_name = action["new"]
            if old_name in header_map:
                ws.cell(row=1, column=header_map[old_name], value=new_name)
                log.append(f"列重命名：「{old_name}」→「{new_name}」")
            else:
                log.append(f"⚠️  列「{old_name}」未找到，跳过")

        # ── format_column ───────────────────────────────────────────────────────
        elif op == "format_column":
            header_map = get_header_map(ws)
            col_name = action["name"]
            fmt      = action["format"]   # e.g. "YYYY-MM-DD", "0.00%", "#,##0.00"
            if col_name in header_map:
                col_idx = header_map[col_name]
                for row in range(2, ws.max_row + 1):
                    ws.cell(row=row, column=col_idx).number_format = fmt
                log.append(f"列「{col_name}」格式设为 {fmt}")
            else:
                log.append(f"⚠️  列「{col_name}」未找到，跳过")

        # ── sort ────────────────────────────────────────────────────────────────
        elif op == "sort":
            header_map = get_header_map(ws)
            col_name   = action["by"]
            ascending  = action.get("ascending", True)

            if col_name not in header_map:
                log.append(f"⚠️  列「{col_name}」未找到，跳过排序")
                continue

            col_idx = header_map[col_name]
            data_rows = []
            for row in ws.iter_rows(min_row=2, values_only=True):
                data_rows.append(list(row))

            def sort_key(r):
                v = r[col_idx - 1]
                return (v is None, v if v is not None else "")

            data_rows.sort(key=sort_key, reverse=not ascending)

            for r_idx, row_data in enumerate(data_rows, start=2):
                for c_idx, val in enumerate(row_data, start=1):
                    ws.cell(row=r_idx, column=c_idx, value=val)

            direction = "升序" if ascending else "降序"
            log.append(f"按「{col_name}」{direction}排序")

        # ── deduplicate ─────────────────────────────────────────────────────────
        elif op == "deduplicate":
            header_map = get_header_map(ws)
            cols = action.get("columns", list(header_map.keys()))
            col_indices = [header_map[c] for c in cols if c in header_map]

            seen = set()
            rows_to_delete = []
            for row in range(2, ws.max_row + 1):
                key = tuple(ws.cell(row=row, column=c).value for c in col_indices)
                if key in seen:
                    rows_to_delete.append(row)
                else:
                    seen.add(key)

            for row in reversed(rows_to_delete):
                ws.delete_rows(row)

            log.append(f"去重完成，删除 {len(rows_to_delete)} 行重复数据")

        # ── pivot_summary ───────────────────────────────────────────────────────
        elif op == "pivot_summary":
            header_map  = get_header_map(ws)
            group_by    = action["group_by"]
            value_col   = action["value"]
            agg         = action.get("aggregate", "sum")   # sum / count / avg

            if group_by not in header_map or value_col not in header_map:
                log.append(f"⚠️  透视所需列未找到，跳过")
                continue

            g_idx = header_map[group_by]
            v_idx = header_map[value_col]

            groups: dict = {}
            for row in range(2, ws.max_row + 1):
                g_val = ws.cell(row=row, column=g_idx).value
                v_val = ws.cell(row=row, column=v_idx).value
                if g_val is None:
                    continue
                try:
                    num = float(v_val) if v_val is not None else 0
                except (ValueError, TypeError):
                    num = 0
                if g_val not in groups:
                    groups[g_val] = []
                groups[g_val].append(num)

            # Create summary sheet
            sheet_name = f"汇总_{group_by}"[:31]
            if sheet_name in wb.sheetnames:
                del wb[sheet_name]
            ws_sum = wb.create_sheet(title=sheet_name)

            # Header
            headers = [group_by, f"{value_col}_{agg}"]
            for c_idx, h in enumerate(headers, start=1):
                cell = ws_sum.cell(row=1, column=c_idx, value=h)
                cell.fill = PatternFill("solid", fgColor=HEADER_BG)
                cell.font = Font(bold=True, color=HEADER_FONT)

            for r_idx, (g_val, nums) in enumerate(sorted(groups.items()), start=2):
                if agg == "sum":
                    result = sum(nums)
                elif agg == "count":
                    result = len(nums)
                elif agg == "avg":
                    result = sum(nums) / len(nums) if nums else 0
                else:
                    result = sum(nums)
                ws_sum.cell(row=r_idx, column=1, value=g_val)
                ws_sum.cell(row=r_idx, column=2, value=round(result, 2))

            log.append(f"生成汇总表「{sheet_name}」，按「{group_by}」分组，{agg}「{value_col}」，共 {len(groups)} 个分组")

        else:
            log.append(f"⚠️  未知操作「{op}」，跳过")

    # Re-apply header style to active sheet
    apply_header_style(ws)
    return log


def main():
    parser = argparse.ArgumentParser(description="Edit existing Excel/CSV file")
    parser.add_argument("--input",   required=True, help="Input .xlsx or .csv path")
    parser.add_argument("--actions", required=True, help="Path to JSON actions file")
    parser.add_argument("--output",  required=True, help="Output .xlsx path")
    args = parser.parse_args()

    wb = load_workbook_or_csv(args.input)

    with open(args.actions, encoding="utf-8") as f:
        actions = json.load(f)

    log = apply_actions(wb, actions)
    wb.save(args.output)

    print(f"✅ 文件已生成：{args.output}")
    print("📋 操作记录：")
    for entry in log:
        print(f"   • {entry}")


if __name__ == "__main__":
    main()
