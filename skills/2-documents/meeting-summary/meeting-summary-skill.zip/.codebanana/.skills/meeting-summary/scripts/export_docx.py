"""
export_docx.py — Convert research-output/*.md to .docx
Usage: python export_docx.py <input.md> [output.docx]
Requires: pip install python-docx
"""
import sys
import re
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    print("Installing python-docx...")
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "python-docx"], check=True)
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH

def md_to_docx(md_path: str, out_path: str = None):
    md = Path(md_path)
    if not md.exists():
        print(f"File not found: {md_path}")
        sys.exit(1)

    out = Path(out_path) if out_path else md.with_suffix(".docx")
    doc = Document()

    # Style defaults
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    lines = md.read_text(encoding="utf-8").splitlines()
    i = 0
    in_code = False
    code_lines = []

    while i < len(lines):
        line = lines[i]

        # Code block
        if line.startswith("```"):
            if in_code:
                in_code = False
                p = doc.add_paragraph()
                p.style = doc.styles["Normal"]
                run = p.add_run("\n".join(code_lines))
                run.font.name = "Courier New"
                run.font.size = Pt(9)
                code_lines = []
            else:
                in_code = True
            i += 1
            continue

        if in_code:
            code_lines.append(line)
            i += 1
            continue

        # Headings
        if line.startswith("### "):
            doc.add_heading(line[4:], level=3)
        elif line.startswith("## "):
            doc.add_heading(line[3:], level=2)
        elif line.startswith("# "):
            doc.add_heading(line[2:], level=1)
        # Horizontal rule
        elif line.strip() in ("---", "***", "___"):
            doc.add_paragraph("─" * 50)
        # Bullet
        elif line.startswith("- ") or line.startswith("* "):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
        # Numbered list
        elif re.match(r"^\d+\.\s", line):
            doc.add_paragraph(re.sub(r"^\d+\.\s", "", line).strip(), style="List Number")
        # Blockquote
        elif line.startswith("> "):
            p = doc.add_paragraph(line[2:])
            p.paragraph_format.left_indent = Inches(0.4)
            run = p.runs[0] if p.runs else p.add_run("")
            run.italic = True
        # Empty line
        elif line.strip() == "":
            doc.add_paragraph("")
        # Normal paragraph (strip inline markdown)
        else:
            text = re.sub(r"\*\*(.+?)\*\*", r"\1", line)
            text = re.sub(r"\*(.+?)\*", r"\1", text)
            text = re.sub(r"`(.+?)`", r"\1", text)
            text = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", text)
            doc.add_paragraph(text)

        i += 1

    doc.save(str(out))
    print(f"✅ Exported: {out}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python export_docx.py <input.md> [output.docx]")
        sys.exit(1)
    md_to_docx(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
