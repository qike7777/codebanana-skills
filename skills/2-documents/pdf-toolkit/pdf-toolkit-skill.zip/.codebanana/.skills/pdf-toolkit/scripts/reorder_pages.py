#!/usr/bin/env python3
"""
reorder_pages.py — Reorder, delete, or rearrange pages in a PDF.

Usage:
    # Reorder by explicit page list (1-indexed)
    python3 reorder_pages.py --input input.pdf --output output.pdf --pages "2,1,4,5"

    # Delete specific pages
    python3 reorder_pages.py --input input.pdf --output output.pdf --delete "3"
    python3 reorder_pages.py --input input.pdf --output output.pdf --delete "3-5"
    python3 reorder_pages.py --input input.pdf --output output.pdf --delete "1,3,5"

    # Reverse all pages
    python3 reorder_pages.py --input input.pdf --output output.pdf --pages "reverse"

    # Keep only odd pages
    python3 reorder_pages.py --input input.pdf --output output.pdf --pages "odd"

    # Keep only even pages
    python3 reorder_pages.py --input input.pdf --output output.pdf --pages "even"
"""

import argparse
import sys
from pypdf import PdfReader, PdfWriter


def parse_page_spec(spec: str, total_pages: int) -> list[int]:
    """
    Parse page specification into 0-indexed page list.
    Input is 1-indexed.
    """
    spec = spec.strip().lower()

    if spec == "reverse":
        return list(range(total_pages - 1, -1, -1))

    if spec == "odd":
        return list(range(0, total_pages, 2))  # pages 1,3,5... (0-indexed: 0,2,4...)

    if spec == "even":
        return list(range(1, total_pages, 2))  # pages 2,4,6... (0-indexed: 1,3,5...)

    pages = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            start_i = int(start.strip()) - 1
            end_i   = int(end.strip()) - 1
            pages.extend(range(start_i, end_i + 1))
        else:
            pages.append(int(part) - 1)

    # Validate
    invalid = [p + 1 for p in pages if p < 0 or p >= total_pages]
    if invalid:
        print(f"❌ 无效页码：{invalid}（文档共 {total_pages} 页）", file=sys.stderr)
        sys.exit(1)

    return pages


def parse_delete_spec(spec: str, total_pages: int) -> list[int]:
    """Parse --delete spec and return the pages to KEEP (0-indexed)."""
    to_delete = set(parse_page_spec(spec, total_pages))
    return [i for i in range(total_pages) if i not in to_delete]


def reorder(input_path: str, output_path: str,
            pages_spec: str = None, delete_spec: str = None) -> None:
    reader = PdfReader(input_path)
    total = len(reader.pages)
    print(f"📄 输入文件：{input_path}（共 {total} 页）")

    if delete_spec:
        page_indices = parse_delete_spec(delete_spec, total)
        action_desc = f"删除指定页后保留 {len(page_indices)} 页"
    elif pages_spec:
        page_indices = parse_page_spec(pages_spec, total)
        action_desc = f"重排为 {len(page_indices)} 页"
    else:
        print("❌ 请指定 --pages 或 --delete", file=sys.stderr)
        sys.exit(1)

    # Preview
    print(f"🔧 操作：{action_desc}")
    preview = [str(i + 1) for i in page_indices]
    if len(preview) <= 20:
        print(f"   新页面顺序：{', '.join(preview)}")
    else:
        print(f"   新页面顺序：{', '.join(preview[:10])} ... {', '.join(preview[-5:])}")

    writer = PdfWriter()
    for idx in page_indices:
        writer.add_page(reader.pages[idx])

    with open(output_path, "wb") as f:
        writer.write(f)

    print(f"\n✅ 完成 → {output_path}（{len(page_indices)} 页）")


def main():
    parser = argparse.ArgumentParser(description="Reorder or delete pages in a PDF")
    parser.add_argument("--input",   required=True, help="Input PDF path")
    parser.add_argument("--output",  required=True, help="Output PDF path")
    parser.add_argument("--pages",   help='New page order, e.g. "2,1,4,5" or "reverse" or "odd" or "even"')
    parser.add_argument("--delete",  help='Pages to delete, e.g. "3" or "3-5" or "1,3,5"')
    args = parser.parse_args()

    if not args.pages and not args.delete:
        parser.print_help()
        sys.exit(1)

    reorder(args.input, args.output, args.pages, args.delete)


if __name__ == "__main__":
    main()
