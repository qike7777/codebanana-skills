#!/usr/bin/env python3
"""
builder.py — Build a new Excel file from a natural language description.
The agent calls this script with a structured JSON config passed via --config,
or with a plain --desc string for simple cases.

Usage:
    python3 builder.py --config config.json
    python3 builder.py --desc "销售跟进表，包含客户名、电话、跟进状态、备注" --output 销售跟进表.xlsx
"""

import argparse
import json
import sys
from pathlib import Path

import openpyxl
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side
)
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation


# ── Default style ──────────────────────────────────────────────────────────────
HEADER_BG   = "1F4E79"
HEADER_FONT = "FFFFFF"
ROW_ALT_BG  = "EBF2FA"
MIN_COL_WIDTH = 14


def make_header_style():
    fill = PatternFill("solid", fgColor=HEADER_BG)
    font = Font(bold=True, color=HEADER_FONT, size=11)
    align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    border = Border(
        bottom=Side(style="medium", color="FFFFFF")
    )
    return fill, font, align, border


def make_alt_fill():
    return PatternFill("solid", fgColor=ROW_ALT_BG)


def auto_col_width(ws):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                if cell.value:
                    max_len = max(max_len, len(str(cell.value)))
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = max(MIN_COL_WIDTH, min(max_len + 4, 50))


# ── Core builder ───────────────────────────────────────────────────────────────
def build_from_config(config: dict, output_path: str):
    """
    config schema:
    {
      "sheets": [
        {
          "name": "Sheet1",
          "columns": [
            {
              "name": "列名",
              "type": "text|number|date|percent|currency",
              "dropdown": ["选项1", "选项2"],          // optional
              "formula": "=A{row}*B{row}",             // optional, {row} replaced
              "highlight_rules": [                      // optional
                {"value": "已成交", "color": "C6EFCE"},
                {"value": "已放弃", "color": "D9D9D9"}
              ]
            }
          ],
          "sample_rows": 3,       // number of example rows to prefill
          "freeze_header": true
        }
      ],
      "filename": "output.xlsx"
    }
    """
    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    header_fill, header_font, header_align, header_border = make_header_style()
    alt_fill = make_alt_fill()

    for sheet_cfg in config.get("sheets", []):
        ws = wb.create_sheet(title=sheet_cfg.get("name", "Sheet1"))
        columns = sheet_cfg.get("columns", [])
        sample_rows = sheet_cfg.get("sample_rows", 3)
        freeze = sheet_cfg.get("freeze_header", True)

        # ── Write header ──
        for col_idx, col in enumerate(columns, start=1):
            cell = ws.cell(row=1, column=col_idx, value=col["name"])
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_align
            cell.border = header_border

        # ── Freeze header ──
        if freeze:
            ws.freeze_panes = "A2"

        # ── Write sample rows ──
        for row_idx in range(2, sample_rows + 2):
            for col_idx, col in enumerate(columns, start=1):
                col_letter = get_column_letter(col_idx)
                formula = col.get("formula", "")
                if formula:
                    value = formula.replace("{row}", str(row_idx))
                else:
                    value = _sample_value(col.get("type", "text"), col.get("name", ""))
                cell = ws.cell(row=row_idx, column=col_idx, value=value)

                # alternating row color
                if row_idx % 2 == 0:
                    cell.fill = alt_fill

                # number formats
                fmt = col.get("type", "text")
                if fmt == "date":
                    cell.number_format = "YYYY-MM-DD"
                elif fmt == "percent":
                    cell.number_format = "0.00%"
                elif fmt == "currency":
                    cell.number_format = '#,##0.00'
                elif fmt == "number":
                    cell.number_format = '#,##0'

        # ── Dropdowns ──
        for col_idx, col in enumerate(columns, start=1):
            dropdown = col.get("dropdown")
            if dropdown:
                col_letter = get_column_letter(col_idx)
                formula_str = '"' + ",".join(dropdown) + '"'
                dv = DataValidation(
                    type="list",
                    formula1=formula_str,
                    allow_blank=True,
                    showErrorMessage=True,
                    errorTitle="无效输入",
                    error="请从下拉列表中选择"
                )
                ws.add_data_validation(dv)
                dv.sqref = f"{col_letter}2:{col_letter}1000"

        # ── Conditional highlight (simple color fill by value) ──
        # Note: openpyxl conditional formatting with color is complex;
        # we apply static colors to sample rows for demonstration.
        for col_idx, col in enumerate(columns, start=1):
            rules = col.get("highlight_rules", [])
            if not rules:
                continue
            rule_map = {r["value"]: r["color"] for r in rules}
            for row_idx in range(2, sample_rows + 2):
                cell = ws.cell(row=row_idx, column=col_idx)
                if cell.value and str(cell.value) in rule_map:
                    cell.fill = PatternFill("solid", fgColor=rule_map[str(cell.value)])

        # ── Auto column width ──
        auto_col_width(ws)

    wb.save(output_path)
    print(f"✅ 文件已生成：{output_path}")
    print(f"   工作表：{[s.title for s in wb.worksheets]}")
    print(f"   总列数：{sum(len(s.get('columns', [])) for s in config.get('sheets', []))}")


def _sample_value(col_type: str, col_name: str) -> str:
    """Return a placeholder sample value based on column type/name."""
    samples = {
        "date":     "2024-01-01",
        "number":   "0",
        "percent":  "0.1",
        "currency": "1000",
        "text":     "示例",
    }
    return samples.get(col_type, "示例")


# ── CLI ────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Build Excel from config or description")
    parser.add_argument("--config", help="Path to JSON config file")
    parser.add_argument("--desc",   help="Plain text description (agent generates config)")
    parser.add_argument("--output", default="output.xlsx", help="Output .xlsx path")
    args = parser.parse_args()

    if args.config:
        with open(args.config, encoding="utf-8") as f:
            config = json.load(f)
        output = args.output or config.get("filename", "output.xlsx")
        build_from_config(config, output)

    elif args.desc:
        # Minimal fallback: create a single-sheet table with generic columns
        # In real usage, the agent generates a proper config JSON and calls --config
        print(f"⚠️  --desc mode: generating minimal template for: {args.desc}")
        config = {
            "sheets": [{
                "name": "Sheet1",
                "columns": [{"name": "列1", "type": "text"}, {"name": "列2", "type": "text"}],
                "sample_rows": 3,
                "freeze_header": True
            }]
        }
        build_from_config(config, args.output)

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
